import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Constants
GRID_SIZE = 4
TILE_SIZE = 100
GRID_MARGIN = 20
GRID_WIDTH = GRID_SIZE * TILE_SIZE + (GRID_SIZE + 1) * GRID_MARGIN
GRID_HEIGHT = GRID_SIZE * TILE_SIZE + (GRID_SIZE + 1) * GRID_MARGIN + 160
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (174, 174, 174)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
FONT_COLOR = (255, 255, 255)
BACKGROUND_COLOR = (205, 193, 180)
GRID_COLOR = (205, 193, 180)
SCORE_COLOR = (119, 110, 101)
BUTTON_COLOR = (119, 110, 101)
BUTTON_TEXT_COLOR = (255, 255, 255)
OVERLAY_COLOR = (255, 255, 255, 128)  # Whitish overlay color
COLOR_DICT = {
    2: WHITE,
    4: GRAY,
    8: (255, 153, 51),
    16: (255, 102, 0),
    32: (255, 51, 51),
    64: (255, 0, 0),
    128: (255, 204, 153),
    256: (255, 178, 102),
    512: (255, 153, 51),
    1024: (255, 128, 0),
    2048: (255, 102, 102),
    4096: (255, 76, 76),
    8192: (255, 51, 51),
    16384: (255, 26, 26),
    32768: (255, 0, 0),
}
FONT_SIZE = 48
BUTTON_FONT_SIZE = 36

# Initialize the screen
screen = pygame.display.set_mode((GRID_WIDTH, GRID_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption('2048 Game')

# Font
font = pygame.font.Font('freesansbold.ttf', FONT_SIZE)
button_font = pygame.font.Font('freesansbold.ttf', BUTTON_FONT_SIZE)

# Load and play background music
pygame.mixer.music.load("mp3/bgmusic.mp3")
pygame.mixer.music.set_volume(1)
pygame.mixer.music.play(-1)  # -1 means the music will loop indefinitely

# Load point sound effect
point_sound = pygame.mixer.Sound("mp3/point.mp3")

# Helper function to draw text on the screen
def draw_text(text, color, x, y, font_size=FONT_SIZE):
    if font_size == FONT_SIZE:
        text_surface = font.render(text, True, color)
    else:
        text_surface = button_font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(x, y))
    screen.blit(text_surface, text_rect)

# Function to generate a new tile (2 or 4)
def new_tile(grid):
    while True:
        x, y = random.randint(0, GRID_SIZE-1), random.randint(0, GRID_SIZE-1)
        if grid[x][y] == 0:
            grid[x][y] = random.choice([2, 4])
            break

# Initialize the grid
def initialize_grid():
    grid = [[0] * GRID_SIZE for _ in range(GRID_SIZE)]
    new_tile(grid)
    new_tile(grid)
    return grid

grid = initialize_grid()

# Function to draw the grid and tiles
def draw_grid():
    # Draw background
    screen.fill(BACKGROUND_COLOR)

    # Draw grid
    pygame.draw.rect(screen, GRID_COLOR, (GRID_MARGIN, GRID_MARGIN, GRID_WIDTH, GRID_HEIGHT - 100))

    for i in range(GRID_SIZE):
        for j in range(GRID_SIZE):
            value = grid[i][j]
            color = COLOR_DICT.get(value, BLACK)
            if value > 4:
                text_color = FONT_COLOR
            else:
                text_color = (119, 110, 101)
            pygame.draw.rect(screen, color, (GRID_MARGIN + j * (TILE_SIZE + GRID_MARGIN),
                                             GRID_MARGIN + i * (TILE_SIZE + GRID_MARGIN),
                                             TILE_SIZE, TILE_SIZE))
            if value != 0:
                text_surface = font.render(str(value), True, text_color)
                text_rect = text_surface.get_rect(center=(GRID_MARGIN + j * (TILE_SIZE + GRID_MARGIN) + TILE_SIZE // 2,
                                                          GRID_MARGIN + i * (TILE_SIZE + GRID_MARGIN) + TILE_SIZE // 2))
                screen.blit(text_surface, text_rect)

# Function to draw the restart button
def draw_restart_button():
    button_rect = pygame.Rect(GRID_WIDTH // 2 - 160, GRID_HEIGHT - 80, 150, 50)
    pygame.draw.rect(screen, BUTTON_COLOR, button_rect)
    draw_text("Restart", BUTTON_TEXT_COLOR, GRID_WIDTH // 2 - 85, GRID_HEIGHT - 55, BUTTON_FONT_SIZE)
    return button_rect

# Function to draw the quit button
def draw_quit_button():
    button_rect = pygame.Rect(GRID_WIDTH // 2 + 10, GRID_HEIGHT - 80, 150, 50)
    pygame.draw.rect(screen, BUTTON_COLOR, button_rect)
    draw_text("Quit", BUTTON_TEXT_COLOR, GRID_WIDTH // 2 + 85, GRID_HEIGHT - 55, BUTTON_FONT_SIZE)
    return button_rect

# Function to draw the continue button
def draw_continue_button():
    button_rect = pygame.Rect(GRID_WIDTH // 2 - 75, GRID_HEIGHT - 100, 150, 50)
    pygame.draw.rect(screen, BUTTON_COLOR, button_rect)
    draw_text("Continue", BUTTON_TEXT_COLOR, GRID_WIDTH // 2, GRID_HEIGHT - 75, BUTTON_FONT_SIZE)
    return button_rect

# Function to move tiles left
def move_left(grid):
    moved = False
    for i in range(GRID_SIZE):
        j, last_merged = 0, False
        for k in range(GRID_SIZE):
            if grid[i][k] != 0:
                if j > 0 and grid[i][j-1] == grid[i][k] and not last_merged:
                    grid[i][j-1] *= 2
                    grid[i][k] = 0
                    last_merged = True
                    moved = True
                elif j != k:
                    grid[i][j], grid[i][k] = grid[i][k], 0
                    moved = True
                    j += 1
                    last_merged = False
                else:
                    j += 1
                    last_merged = False
    return moved

# Function to move tiles right
def move_right(grid):
    moved = False
    for i in range(GRID_SIZE):
        j, last_merged = GRID_SIZE - 1, False
        for k in range(GRID_SIZE - 1, -1, -1):
            if grid[i][k] != 0:
                if j < GRID_SIZE - 1 and grid[i][j+1] == grid[i][k] and not last_merged:
                    grid[i][j+1] *= 2
                    grid[i][k] = 0
                    last_merged = True
                    moved = True
                elif j != k:
                    grid[i][j], grid[i][k] = grid[i][k], 0
                    moved = True
                    j -= 1
                    last_merged = False
                else:
                    j -= 1
                    last_merged = False
    return moved

# Function to move tiles up
def move_up(grid):
    moved = False
    for j in range(GRID_SIZE):
        i, last_merged = 0, False
        for k in range(GRID_SIZE):
            if grid[k][j] != 0:
                if i > 0 and grid[i-1][j] == grid[k][j] and not last_merged:
                    grid[i-1][j] *= 2
                    grid[k][j] = 0
                    last_merged = True
                    moved = True
                elif i != k:
                    grid[i][j], grid[k][j] = grid[k][j], 0
                    moved = True
                    i += 1
                    last_merged = False
                else:
                    i += 1
                    last_merged = False
    return moved

# Function to move tiles down
def move_down(grid):
    moved = False
    for j in range(GRID_SIZE):
        i, last_merged = GRID_SIZE - 1, False
        for k in range(GRID_SIZE - 1, -1, -1):
            if grid[k][j] != 0:
                if i < GRID_SIZE - 1 and grid[i+1][j] == grid[k][j] and not last_merged:
                    grid[i+1][j] *= 2
                    grid[k][j] = 0
                    last_merged = True
                    moved = True
                elif i != k:
                    grid[i][j], grid[k][j] = grid[k][j], 0
                    moved = True
                    i -= 1
                    last_merged = False
                else:
                    i -= 1
                    last_merged = False
    return moved

# Function to check if the game is over
def is_game_over(grid):
    for i in range(GRID_SIZE):
        for j in range(GRID_SIZE):
            if grid[i][j] == 0:
                return False
            if j > 0 and grid[i][j] == grid[i][j-1]:
                return False
            if i > 0 and grid[i][j] == grid[i-1][j]:
                return False
    return True

# Function to check if the player has won
def has_won(grid):
    for i in range(GRID_SIZE):
        for j in range(GRID_SIZE):
            if grid[i][j] == 2048:
                return True
    return False

# Main game loop
game_over = False
won = False
continue_playing = False
previous_score = 0  # Initialize previous score

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            moved = False
            if event.key == pygame.K_LEFT and not game_over:
                moved = move_left(grid)
            elif event.key == pygame.K_RIGHT and not game_over:
                moved = move_right(grid)
            elif event.key == pygame.K_UP and not game_over:
                moved = move_up(grid)
            elif event.key == pygame.K_DOWN and not game_over:
                moved = move_down(grid)
            if moved:
                new_tile(grid)
                
                # Check for score increase
                current_score = sum(sum(row) for row in grid)
                if current_score > previous_score:
                    point_sound.play()
                    previous_score = current_score
                
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:  # Left mouse button
                mouse_pos = pygame.mouse.get_pos()
                if restart_button.collidepoint(mouse_pos):
                    grid = initialize_grid()
                    game_over = False
                    won = False
                    continue_playing = False
                    previous_score = 0  # Reset previous score
                elif quit_button.collidepoint(mouse_pos):
                    pygame.quit()
                    sys.exit()
                if won and continue_button.collidepoint(mouse_pos):
                    continue_playing = True

    # Draw the grid and tiles
    draw_grid()

    # Draw the score
    score = sum(sum(row) for row in grid)
    draw_text(f'Score: {score}', SCORE_COLOR, GRID_WIDTH // 2, GRID_HEIGHT - 120)

    # Draw the restart button
    restart_button = draw_restart_button()
    
    # Draw the quit button
    quit_button = draw_quit_button()

    # Check for game over
    if is_game_over(grid):
        game_over = True
        pygame.mixer.music.load("mp3/gameOver.mp3")
        pygame.mixer.music.set_volume(1)
        pygame.mixer.music.play()
        # Whitish overlay
        overlay = pygame.Surface((GRID_WIDTH, GRID_HEIGHT))
        overlay.fill(OVERLAY_COLOR)
        screen.blit(overlay, (0, 0))
        draw_text("Game Over!", RED, GRID_WIDTH // 2, GRID_HEIGHT // 2)
        restart_button = draw_restart_button()
        quit_button = draw_quit_button()

    # Check for win condition
    if has_won(grid) and not continue_playing:
        won = True
        draw_text("You Win!", GREEN, GRID_WIDTH // 2, GRID_HEIGHT // 2 - 50)
        draw_text("Press 'R' to restart or 'Q' to quit", FONT_COLOR, GRID_WIDTH // 2, GRID_HEIGHT // 2)
        draw_text("or click 'Continue' to keep playing", FONT_COLOR, GRID_WIDTH // 2, GRID_HEIGHT // 2 + 50)
        continue_button = draw_continue_button()
        game_over = True

    pygame.display.flip()
